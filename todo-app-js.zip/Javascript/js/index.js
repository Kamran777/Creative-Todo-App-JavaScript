var count = 0;

document.querySelector('#push').onclick = function(){
    if(document.querySelector('#newtask input').
    value.length === 0){
        alert("Please input a text!")
    }else{
        document.querySelector('#tasks').style.display = "block";
        document.querySelector('#tasks').innerHTML
        += `
            <div class="task">
                <span id="taskname">
                    ${document.querySelector('#newtask input').
                      value}
                </span>
                <button class="delete">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        `;

        count++;

        var current_tasks = document.querySelectorAll('.delete');
        for(var i = 0; i < current_tasks.length; i++){
            current_tasks[i].onclick = function(){
                this.parentNode.remove();
                count--;
                if(count === 0){
                    document.querySelector('#tasks').style.display = "none";
                }
            }
        }

        var tasks = document.querySelectorAll('.task');
        for(var i = 0; i < tasks.length; i++){
            tasks[i].onclick = function(){
                this.classList.toggle('completed');
            }
        }

        document.querySelector('#newtask input').
        value = '';
    }
}